## Inputs

- Project name
- Version number if provided, otherwise default to `V1.0.0`
- Provider name if provided
- Frontend and backend code paths, or one codebase root
- Optional screenshot file paths
- Optional placeholder image path for all figures

## User Manual Rules

- Generate a `.docx` user manual.
- Cover page:
  - Center the software name and `User Manual` equivalent content.
  - Put `Version: ...` and `Provider: ...` near the bottom of the cover page.
  - Do not add extra lines such as audience or system scope unless the user explicitly asks.
- Add a real Word TOC field so the user can update the directory in Word.
- Main body should include numbered sections, module descriptions, operation steps, and screenshot placement notes.
- If screenshots are missing, still keep figure positions and captions ready.
- Put figure labels such as `Figure 6-5` or the user's preferred label format centered below each image.

## Source Code Rules

- Generate a `.docx` source-code document.
- Target up to 3000 lines (60 pages × 50 lines per page) when the filtered source is sufficient.
- Each page must show exactly 50 visible lines in Word when paginated; the final page may contain fewer lines.
- Remove empty lines.
- Comments are allowed.
- Remove lines containing `author`, `create`, or `copyright`, case-insensitive.
- Remove dates from comment lines.
- If total source exceeds 3000 lines, compose from the first continuous 30 pages and the last continuous 30 pages worth of content.
- If filtered source is less than 3000 lines, include all available continuous content and stop normally.
- Never insert placeholder filler lines such as `# padding`, `// padding`, or similar artificial padding to reach 3000 lines.
- The final line must be a valid terminator such as `end` or another language-appropriate end marker.
- Include software name, version, and page number in header/footer if requested.

## Workflow

1. Collect the minimum required inputs.
2. Build the user manual first.
3. Build the source-code document second.
4. Build the features summary document third.
5. Verify the source-code document against line-count and filtering rules.
6. Save outputs with project-name-based filenames.

## Features Summary Rules (功能特点)

Generate `<project-name>-功能特点.docx` (and convert to `.doc` when possible).

Required registration fields and length targets:

| Field | Limit | Target |
|-------|-------|--------|
| 开发目的 | 30–50 characters | ~38 characters |
| 面向领域／行业 | within 50 characters | ~34 characters |
| 软件的主要功能 | 500–1300 characters | ~800–900 characters |

Rules:

- Write from the actual project code and user manual; do not pad to the upper limit.
- Do not write shorter than the lower limit.
- Prefer the middle of each range over boundary values.
- 开发目的: state development intent and business outcome in concise registration language.
- 面向领域／行业: cross-border e-commerce, industry keywords, and application scope in one sentence.
- 软件的主要功能: cover data input, validation/matching, core business logic, classification/rules, output format, and GUI workflow based on real modules.
- Include companion rows in the same table/document: 软件名称, 版本号, 著作权人, 硬件/软件环境, 编程语言, 源程序量, 技术特点, etc.

## Output Files

- `<project-name>-用户手册.docx`
- `<project-name>-源代码.docx`
- `<project-name>-功能特点.docx`
- `<project-name>-功能特点.doc` (optional, converted from docx)
- Optional `<project-name>-源代码说明.txt`
