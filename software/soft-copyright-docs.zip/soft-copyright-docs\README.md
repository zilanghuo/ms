# 软著材料生成 Skill（soft-copyright-docs）

用于让 AI 助手按统一规范生成软件著作权登记材料：

- 用户手册（.docx）
- 源代码文档（.docx）
- 功能特点（.docx / .doc）

## 目录结构

```
soft-copyright-docs/
├── SKILL.md                 # 主 skill 说明（必选）
├── references/
│   └── rules.md             # 详细规则（页数、行数、功能特点字段等）
├── scripts/
│   └── generate_expert_soft_copyright_materials.py  # 参考生成脚本
└── agents/
    └── openai.yaml          # Codex 可选配置
```

## 安装方式

### Cursor

将整个 `soft-copyright-docs` 文件夹复制到：

```
C:\Users\<你的用户名>\.cursor\skills\soft-copyright-docs\
```

或在任意项目的：

```
.cursor/skills/soft-copyright-docs/
```

### Codex / Claude Code

将整个 `soft-copyright-docs` 文件夹复制到：

```
C:\Users\<你的用户名>\.codex\skills\soft-copyright-docs\
```

复制后重启 IDE 或新开对话即可生效。

## 使用示例

向 AI 说明：

> 请使用 soft-copyright-docs skill，为「XXX软件」生成软著材料。
> 源码路径：xxx.py
> 参考材料目录：...
> 输出目录：...

## 核心规则摘要

| 材料 | 要点 |
|------|------|
| 用户手册 | >13 页，含封面、目录域、模块说明与截图位 |
| 源代码 | 每页 50 行；代码不足时不使用 `# padding` 填充，正常以 `end` 结束 |
| 功能特点 | 必含「开发目的」「面向领域／行业」「软件的主要功能」，取字数区间中间值 |

详细规则见 `references/rules.md`。

## 依赖

生成脚本需 Python 3.8+ 及 `python-docx`：

```bash
pip install python-docx
```

Windows 下若需 `.doc` 转换，需安装 Microsoft Word（可选）。
