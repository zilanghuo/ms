from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from textwrap import wrap
from typing import Iterable, List

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


ROOT = Path(r"E:\project\ms\ms-business")
FRONT_ROOT = Path(r"C:\workplace\java\ms-cloud\ms-cloud-front")
OUTPUT_DIR = ROOT / "软著生成材料"

SYSTEM_NAME = "东南亚海外商务达人管理系统"
VERSION = "V1.0.0"
COMPANY = "厦门麻生环球科技有限公司"
MANUAL_PLACEHOLDER_IMAGE = Path(r"C:\Users\Administrator\Desktop\图片1.png")

CODE_LINES_PER_PAGE = 50
CODE_PAGE_COUNT = 60
CODE_TOTAL_LINES = CODE_LINES_PER_PAGE * CODE_PAGE_COUNT
CODE_WRAP_WIDTH = 86
FORBIDDEN_WORDS = ("author", "create", "copyright")
DATE_PATTERNS = [
    re.compile(r"\b20\d{2}[-/.年]\d{1,2}[-/.月]\d{1,2}\b"),
    re.compile(r"\b20\d{2}-\d{1,2}-\d{1,2}\s+\d{1,2}:\d{2}:\d{2}\b"),
]


@dataclass
class CodeFile:
    path: Path


def set_doc_defaults(document: Document) -> None:
    style = document.styles["Normal"]
    style.font.name = "宋体"
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    style.font.size = Pt(12)
    for section in document.sections:
        section.page_width = Cm(21.0)
        section.page_height = Cm(29.7)
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(3.0)
        section.right_margin = Cm(2.5)


def add_heading_paragraph(document: Document, text: str, level: int) -> None:
    p = document.add_paragraph()
    p.style = f"Heading {level}"
    fmt = p.paragraph_format
    fmt.space_after = Pt(0)
    fmt.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    r = p.add_run(text)
    r.bold = True
    r.font.name = "黑体" if level <= 2 else "宋体"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体" if level <= 2 else "宋体")
    r.font.size = Pt(16 if level == 1 else 14 if level == 2 else 12)


def add_manual_paragraph(document: Document, text: str, indent: bool = True) -> None:
    p = document.add_paragraph()
    fmt = p.paragraph_format
    fmt.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
    fmt.space_after = Pt(0)
    if indent:
        fmt.first_line_indent = Cm(0.74)
    p.add_run(text)


def add_bullets(document: Document, items: Iterable[str]) -> None:
    for item in items:
        p = document.add_paragraph(style="List Bullet")
        fmt = p.paragraph_format
        fmt.line_spacing_rule = WD_LINE_SPACING.ONE_POINT_FIVE
        fmt.space_after = Pt(0)
        p.add_run(item)


def add_figure(document: Document, figure_no: str, caption: str) -> None:
    add_manual_paragraph(document, "截图位置说明：", indent=False)
    add_manual_paragraph(document, caption, indent=False)
    if MANUAL_PLACEHOLDER_IMAGE.exists():
        p = document.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run()
        run.add_picture(str(MANUAL_PLACEHOLDER_IMAGE), width=Cm(15.5))
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(figure_no)
    r.font.name = "宋体"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    r.font.size = Pt(12)


def add_toc_field(document: Document) -> None:
    p = document.add_paragraph()
    run = p.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = 'TOC \\o "1-3" \\h \\u'
    fld_sep = OxmlElement("w:fldChar")
    fld_sep.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "更新目录"
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_sep)
    run._r.append(text)
    run._r.append(fld_end)


def add_manual_cover_page(document: Document) -> None:
    for _ in range(2):
        document.add_paragraph("")

    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(SYSTEM_NAME)
    r.bold = True
    r.font.name = "黑体"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
    r.font.size = Pt(24)

    document.add_paragraph("")
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("用户手册")
    r.bold = True
    r.font.name = "黑体"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
    r.font.size = Pt(22)

    for _ in range(12):
        document.add_paragraph("")

    for line in [f"版本：{VERSION}", f"提供方：{COMPANY}"]:
        p = document.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(line)
        r.font.name = "宋体"
        r._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
        r.font.size = Pt(14)


def add_manual_body(document: Document) -> None:
    add_heading_paragraph(document, "一、文档历史", 1)
    add_manual_paragraph(document, f"{SYSTEM_NAME}用户手册当前版本为{VERSION}。本文档依据当前系统页面和程序实现编写，用于软件著作权申报和系统使用说明。")

    add_heading_paragraph(document, "二、引言", 1)
    add_heading_paragraph(document, "2.1 编写目的", 2)
    add_manual_paragraph(document, "本文档用于说明东南亚海外商务达人管理系统的主要功能、业务流程和典型操作方法，帮助用户快速掌握系统的使用方式，并为软件著作权登记提供配套的用户文档。")
    add_heading_paragraph(document, "2.2 系统简介", 2)
    add_manual_paragraph(document, "东南亚海外商务达人管理系统面向海外达人合作业务场景建设，围绕店铺PID、脚本资源、合作进度和素材回收等核心数据，形成统一录入、查询、跟进、审核、导入导出与归档管理闭环。")
    add_heading_paragraph(document, "2.3 技术架构", 2)
    add_manual_paragraph(document, "系统采用前后端分离架构。前端基于Vue3、Vite和Element Plus实现页面交互，后端基于Spring Boot、Spring Cloud Alibaba、MyBatis-Plus和MySQL实现业务接口、权限控制、数据校验以及导入导出功能。")

    add_heading_paragraph(document, "三、系统概述", 1)
    add_heading_paragraph(document, "3.1 业务流程概述", 2)
    add_bullets(document, [
        "先在店铺PID管理中维护店铺、产品和PID基础关系。",
        "再在脚本编号管理中维护推广脚本资源。",
        "业务人员在合作进度管理中录入达人合作信息、业务归属和合作状态。",
        "达人发布视频后，在素材回收管理中登记视频、订单量、回收状态和授权码信息。",
        "系统支持重点达人申请、审核、导出和历史关系追溯。",
    ])
    add_heading_paragraph(document, "3.2 功能模块", 2)
    add_bullets(document, [
        "店铺PID管理",
        "脚本编号管理",
        "合作进度管理",
        "素材回收管理",
    ])

    add_heading_paragraph(document, "四、店铺PID管理", 1)
    add_manual_paragraph(document, "功能说明：店铺PID管理用于维护店铺名称、产品名称、产品PID、PID后四位、是否月度安排、国家和状态等基础数据，为合作进度和素材回收提供关联依据。")
    add_manual_paragraph(document, "操作步骤：1. 进入“业务管理→达人管理→店铺PID管理”；2. 使用店铺、产品名称、月度安排等条件查询；3. 点击“新增”录入店铺、产品和PID信息；4. 点击“批量导入”可导入Excel；5. 可对记录执行启用、停用和编辑操作。")
    add_figure(document, "图4-1", "图4-1：业务管理→达人管理→店铺PID管理→列表页面（显示店铺、产品、PID和状态信息）")
    add_figure(document, "图4-2", "图4-2：业务管理→达人管理→店铺PID管理→新增/编辑对话框（显示店铺、产品、PID和国家字段）")

    add_heading_paragraph(document, "五、脚本编号管理", 1)
    add_manual_paragraph(document, "功能说明：脚本编号管理用于维护推广脚本编号、脚本图片、适用产品、国家、脚本状态和脚本说明，便于脚本资源统一管理。")
    add_manual_paragraph(document, "操作步骤：1. 进入“业务管理→达人管理→脚本编号管理”；2. 按产品名称和脚本状态筛选；3. 点击“新增”录入脚本编号、图片地址、产品名称和说明；4. 可对脚本执行编辑、启用和停用操作。")
    add_figure(document, "图5-1", "图5-1：业务管理→达人管理→脚本编号管理→列表页面（显示脚本编号、产品名称、国家和状态信息）")
    add_figure(document, "图5-2", "图5-2：业务管理→达人管理→脚本编号管理→新增/编辑对话框（显示脚本编号、图片地址和脚本说明字段）")

    add_heading_paragraph(document, "六、合作进度管理", 1)
    add_manual_paragraph(document, "功能说明：合作进度管理用于登记达人账号、KOL编号、业务归属、店铺PID、脚本编号、粉丝数、GMV、联系方式、发货时间、合作状态、重点达人状态等信息，是达人合作业务的核心模块。")
    add_manual_paragraph(document, "操作步骤：1. 进入“业务管理→达人管理→合作进度管理”；2. 使用达人账号、合作状态、业务归属等条件查询；3. 点击“新增”录入达人基础信息和业务信息；4. 可进行编辑、删除、批量导入、导出和重点达人申请；5. 审核人员可对重点达人执行审核和驳回操作。")
    add_figure(document, "图6-1", "图6-1：业务管理→达人管理→合作进度管理→列表页面（显示达人账号、KOL编号、PID、合作状态等信息）")
    add_figure(document, "图6-2", "图6-2：业务管理→达人管理→合作进度管理→新增/编辑对话框（显示达人基础信息、业务归属和合作字段）")
    add_figure(document, "图6-3", "图6-3：业务管理→达人管理→合作进度管理→绑定业务对话框（显示历史业务归属与绑定操作）")
    add_figure(document, "图6-4", "图6-4：业务管理→达人管理→合作进度管理→重点达人审核对话框（显示审核记录与审核操作）")

    add_heading_paragraph(document, "七、素材回收管理", 1)
    add_manual_paragraph(document, "功能说明：素材回收管理用于维护达人视频素材数据，包括视频ID、发布时间、视频链接、订单量、素材类型、素材等级、回收状态、授权码、审核结果和素材文案等信息，并支持分组视图和批量导入。")
    add_manual_paragraph(document, "操作步骤：1. 进入“业务管理→达人管理→素材回收管理”；2. 按达人账号、PID、订单量、素材等级等筛选；3. 点击“新增”录入素材信息；4. 可执行批量新增、导入订单量、修改回收状态、导出和查看详情；5. 分组视图可按账号、PID和等级聚合查看数据。")
    add_figure(document, "图7-1", "图7-1：业务管理→达人管理→素材回收管理→列表页面（显示素材基础信息和回收状态）")
    add_figure(document, "图7-2", "图7-2：业务管理→达人管理→素材回收管理→新增/编辑对话框（显示视频、订单量、等级和授权码字段）")
    add_figure(document, "图7-3", "图7-3：业务管理→达人管理→素材回收管理→分组视图页面（显示按达人或PID聚合的素材数据）")

    add_heading_paragraph(document, "八、注意事项", 1)
    add_bullets(document, [
        "建议先维护店铺PID和脚本基础数据，再录入合作与素材信息。",
        "导入Excel前应先检查模板字段、必填项和数据格式。",
        "重点达人申请、审核和驳回属于关键业务操作，应严格按权限执行。",
        "素材回收中的授权码、订单量和回收状态应保持及时更新。",
    ])


def build_manual() -> Path:
    document = Document()
    set_doc_defaults(document)
    add_manual_cover_page(document)
    document.add_page_break()
    add_heading_paragraph(document, "目录", 1)
    add_toc_field(document)
    document.add_page_break()
    add_manual_body(document)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_DIR / f"{SYSTEM_NAME}-用户手册.docx"
    document.save(out_path)
    return out_path


def gather_code_files() -> List[CodeFile]:
    file_paths = [
        ROOT / "server-business/src/main/java/com/ms/business/expert/controller/ExpertManageController.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/controller/ExpertMaterialRecycleController.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/controller/ExpertScriptCodeController.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/controller/ExpertShopPidController.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/service/impl/ExpertManageServiceImpl.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/service/impl/ExpertMaterialRecycleServiceImpl.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/service/impl/ExpertScriptCodeServiceImpl.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/service/impl/ExpertShopPidServiceImpl.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/mapper/ExpertManageMapper.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/mapper/ExpertMaterialRecycleMapper.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/mapper/ExpertScriptCodeMapper.java",
        ROOT / "server-business/src/main/java/com/ms/business/expert/mapper/ExpertShopPidMapper.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/domain/expert/ExpertManage.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/domain/expert/ExpertMaterialRecycle.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/domain/expert/ExpertScriptCode.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/domain/expert/ExpertShopPid.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertManageAddRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertManageEditRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertManageListRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertMaterialRecycleAddRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertMaterialRecycleEditRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertMaterialRecycleListRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertScriptCodeAddRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertScriptCodeEditRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertShopPidAddRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/request/expert/ExpertShopPidEditRequest.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/response/expert/ExpertManageListResponse.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/response/expert/ExpertMaterialRecycleListResponse.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/response/expert/ExpertScriptCodeListResponse.java",
        ROOT / "api-business/src/main/java/com/ms/business/api/response/expert/ExpertShopPidListResponse.java",
        FRONT_ROOT / "src/api/business/expert/cooperationProgress.js",
        FRONT_ROOT / "src/api/business/expert/materialRecycle.js",
        FRONT_ROOT / "src/api/business/expert/scriptCode.js",
        FRONT_ROOT / "src/api/business/expert/shopPid.js",
        FRONT_ROOT / "src/views/business/expert/cooperationProgress/index.vue",
        FRONT_ROOT / "src/views/business/expert/cooperationProgress/components/BindBusinessDialog.vue",
        FRONT_ROOT / "src/views/business/expert/cooperationProgress/components/CooperationProgressDetailDialog.vue",
        FRONT_ROOT / "src/views/business/expert/cooperationProgress/components/CooperationProgressFormDialog.vue",
        FRONT_ROOT / "src/views/business/expert/cooperationProgress/components/FocusExpertAuditDialog.vue",
        FRONT_ROOT / "src/views/business/expert/materialRecycle/index.vue",
        FRONT_ROOT / "src/views/business/expert/materialRecycle/components/MaterialRecycleDetailDialog.vue",
        FRONT_ROOT / "src/views/business/expert/materialRecycle/components/MaterialRecycleFormDialog.vue",
        FRONT_ROOT / "src/views/business/expert/scriptCode/index.vue",
        FRONT_ROOT / "src/views/business/expert/scriptCode/components/ScriptCodeFormDialog.vue",
        FRONT_ROOT / "src/views/business/expert/shopPid/index.vue",
        FRONT_ROOT / "src/views/business/expert/shopPid/components/ShopPidFormDialog.vue",
    ]
    return [CodeFile(path=p) for p in file_paths if p.exists()]


def read_text_lines(path: Path) -> List[str]:
    return path.read_text(encoding="utf-8", errors="ignore").splitlines()


def is_forbidden_line(line: str) -> bool:
    lowered = line.lower()
    if any(word in lowered for word in FORBIDDEN_WORDS):
        return True
    stripped = line.strip()
    if stripped.startswith("//") or stripped.startswith("*") or stripped.startswith("/*") or stripped.startswith("*/"):
        if any(pattern.search(stripped) for pattern in DATE_PATTERNS):
            return True
    return False


def wrap_visible_line(line: str) -> List[str]:
    if not line.strip():
        return []
    if len(line) <= CODE_WRAP_WIDTH:
        return [line]
    indent_len = len(line) - len(line.lstrip(" "))
    indent = " " * min(indent_len, 16)
    return wrap(
        line,
        width=CODE_WRAP_WIDTH,
        replace_whitespace=False,
        drop_whitespace=False,
        break_long_words=True,
        break_on_hyphens=False,
        subsequent_indent=indent + "    ",
    )


def build_code_lines(code_files: List[CodeFile]) -> List[str]:
    all_lines: List[str] = []
    for code_file in code_files:
        all_lines.extend(wrap_visible_line(f"// File: {code_file.path}"))
        for raw in read_text_lines(code_file.path):
            line = raw.rstrip("\n\r").expandtabs(4)
            if line.strip() and not is_forbidden_line(line):
                all_lines.extend(wrap_visible_line(line))

    if len(all_lines) > CODE_TOTAL_LINES - 1:
        half = (CODE_TOTAL_LINES - 1) // 2
        head = all_lines[:half]
        tail = all_lines[-half:]
        lines = head + tail
    else:
        lines = list(all_lines)

    if len(lines) >= CODE_TOTAL_LINES:
        lines = lines[: CODE_TOTAL_LINES - 1]
    lines.append("end")
    return lines


def add_page_number_run(paragraph) -> None:
    run = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = "PAGE"
    fld_sep = OxmlElement("w:fldChar")
    fld_sep.set(qn("w:fldCharType"), "separate")
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_sep)
    run._r.append(fld_end)


def set_section_line_numbering_and_grid(section) -> None:
    sect_pr = section._sectPr
    ln = sect_pr.find(qn("w:lnNumType"))
    if ln is None:
        ln = OxmlElement("w:lnNumType")
        sect_pr.append(ln)
    ln.set(qn("w:countBy"), "0")

    grid = sect_pr.find(qn("w:docGrid"))
    if grid is None:
        grid = OxmlElement("w:docGrid")
        sect_pr.append(grid)
    grid.set(qn("w:linePitch"), "442")
    grid.set(qn("w:charSpace"), "0")


def configure_code_document(document: Document) -> None:
    style = document.styles["Normal"]
    style.font.name = "Courier New"
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    style.font.size = Pt(9)

    section = document.sections[0]
    section.page_width = Cm(21.0)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(1.524)
    section.bottom_margin = Cm(1.524)
    section.left_margin = Cm(1.27)
    section.right_margin = Cm(1.27)
    section.header_distance = Cm(1.27)
    section.footer_distance = Cm(1.27)
    set_section_line_numbering_and_grid(section)

    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    hr = header.add_run(f"{SYSTEM_NAME} {VERSION}")
    hr.font.name = "宋体"
    hr._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    hr.font.size = Pt(9)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r1 = footer.add_run(f"{SYSTEM_NAME} {VERSION}  第 ")
    r1.font.name = "宋体"
    r1._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    r1.font.size = Pt(9)
    add_page_number_run(footer)
    r2 = footer.add_run(" 页")
    r2.font.name = "宋体"
    r2._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    r2.font.size = Pt(9)


def add_code_line(document: Document, text: str) -> None:
    p = document.add_paragraph()
    fmt = p.paragraph_format
    fmt.space_before = Pt(0)
    fmt.space_after = Pt(0)
    fmt.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    fmt.line_spacing = Pt(14.7)
    fmt.first_line_indent = Pt(0)
    fmt.left_indent = Pt(0)
    fmt.right_indent = Pt(0)
    fmt.keep_together = True
    fmt.keep_with_next = False
    fmt.widow_control = False
    r = p.add_run(text)
    r.font.name = "Courier New"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    r.font.size = Pt(9)


def build_code_document(code_lines: List[str], code_files: List[CodeFile]) -> tuple[Path, Path]:
    document = Document()
    set_doc_defaults(document)
    configure_code_document(document)
    for line in code_lines:
        add_code_line(document, line)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    out_path = OUTPUT_DIR / f"{SYSTEM_NAME}-源代码.docx"
    document.save(out_path)

    summary_path = OUTPUT_DIR / f"{SYSTEM_NAME}-源代码说明.txt"
    with summary_path.open("w", encoding="utf-8") as f:
        f.write(f"系统名称：{SYSTEM_NAME}\n")
        f.write(f"源代码页数：{CODE_PAGE_COUNT}\n")
        f.write(f"每页行数：{CODE_LINES_PER_PAGE}\n")
        f.write(f"实际写入行数：{len(code_lines)}\n")
        f.write(f"目标行数上限：{CODE_TOTAL_LINES}\n")
        f.write(f"折行宽度：{CODE_WRAP_WIDTH}\n")
        f.write("纳入源码的文件列表：\n")
        for item in code_files:
            f.write(f"- {item.path}\n")
    return out_path, summary_path


def main() -> None:
    manual_path = build_manual()
    code_files = gather_code_files()
    code_lines = build_code_lines(code_files)
    code_path, summary_path = build_code_document(code_lines, code_files)
    print(manual_path)
    print(code_path)
    print(summary_path)


if __name__ == "__main__":
    main()
