---
name: soft-copyright-docs
description: Generate software copyright filing documents from a project name, codebase paths, and optional screenshots. Use when the user wants a reusable user manual and source-code document in .docx format for software copyright registration.
---

# Soft Copyright Docs

Generate three filing documents for software copyright registration:

- a user manual
- a source-code document
- a features summary document (功能特点)

Read [references/rules.md](references/rules.md) before drafting or generating files.

## Workflow

1. Collect the core inputs:
   - project name
   - version if provided, otherwise `V1.0.0`
   - provider name if provided
   - code paths
   - optional screenshot paths or one placeholder image path
2. Build the user manual.
3. Build the source-code document.
4. Build the features summary document (功能特点).
5. Verify pagination, line count, filtering, and terminator rules.
6. Save the generated `.docx` files using the project name.

## Manual Rules

- Keep the cover simple.
- Put version and provider near the bottom of the cover page.
- Add a real Word TOC field.
- For each module, include:
  - function description
  - operation steps
  - screenshot placement notes
- If screenshots are missing, keep placeholder figure positions ready.
- Put figure labels centered below each image.

## Source Code Rules

- Use visible line count, not paragraph count, as the source of truth.
- Remove empty lines.
- Allow comments.
- Remove lines containing `author`, `create`, or `copyright`.
- Remove comment dates.
- When source volume exceeds 3000 lines, compose from the first 30 pages and last 30 pages worth of continuous content.
- When source volume is less than 3000 lines, include all filtered content and end normally; do not pad with placeholder lines such as `# padding` or `// padding`.
- End the document with `end` or another valid terminator.

## Features Summary Rules (功能特点)

Every project must include a features summary file with at least these three registration fields. Draft from the actual codebase; do not copy unrelated projects verbatim.

| Field | Limit | Target length |
|-------|-------|---------------|
| 开发目的 | 30–50 characters | about 38 characters |
| 面向领域／行业 | within 50 characters | about 34 characters |
| 软件的主要功能 | 500–1300 characters | about 800–900 characters |

Writing rules:

- Aim for the middle of each range; do not deliberately max out or min out the limits.
- Use complete sentences and registration-style wording in Simplified Chinese.
- 开发目的: one or two sentences on why the software exists and the business value.
- 面向领域／行业: one sentence listing industry/domain keywords.
- 软件的主要功能: structured narrative covering inputs, core processing, outputs, and UI; mention real modules and business rules from the code.
- Also include the other standard rows when generating the full 功能特点 document (version, hardware, tech stack, 技术特点, etc.).
- Output both `.docx` and `.doc` when possible to match existing filing templates.

## Implementation Notes

- Prefer deterministic generation scripts when available.
- If a local project already has a working generator, adapt it instead of rewriting from scratch.
- If the user is iterating on layout, change one pagination parameter at a time and regenerate.
